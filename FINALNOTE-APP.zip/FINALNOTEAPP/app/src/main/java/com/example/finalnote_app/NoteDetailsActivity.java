package com.example.finalnote_app;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;

public class NoteDetailsActivity extends AppCompatActivity {

    EditText titleEditText, contentEditText;
    ImageButton saveNoteBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_note_details);

        titleEditText = findViewById(R.id.notes_title_text);
        contentEditText = findViewById(R.id.notes_content_text);
        saveNoteBtn = findViewById(R.id.save_note_btn);

        saveNoteBtn.setOnClickListener((v) -> saveNote());
    }

    void saveNote() {
        String noteTitle = titleEditText.getText().toString();
        String noteContent = contentEditText.getText().toString();

        if (noteTitle == null || noteTitle.isEmpty()) {
            titleEditText.setError("Title is required");
            return;
        }

        // Now you can save the note to SQLite
        saveNoteToSQLite(noteTitle, noteContent);

        // You might also want to navigate back to the MainActivity or perform other actions after saving.
        // For example:
        // startActivity(new Intent(NoteDetailsActivity.this, MainActivity.class));
    }

    private void saveNoteToSQLite(String title, String content) {
        // You need to use the same DatabaseHelper instance as in MainActivity
        DatabaseHelper dbHelper = new DatabaseHelper(this);
        SQLiteDatabase database = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("content", content);

        long rowId = database.insert("NoteTable", null, values);

        if (rowId != -1) {
            // Note saved successfully
        } else {
            // Failed to save note
        }

        // Don't forget to close the database
        dbHelper.close();
    }
}
