package com.example.finalnote_app;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;

public class NoteDao {
    private SQLiteDatabase database;

    public NoteDao(SQLiteDatabase database) {
        this.database = database;
    }

    public long insert(Note note) {
        ContentValues values = new ContentValues();
        values.put("title", note.getTitle());
        values.put("content", note.getContent());

        return database.insert("notes", null, values);
    }
}
