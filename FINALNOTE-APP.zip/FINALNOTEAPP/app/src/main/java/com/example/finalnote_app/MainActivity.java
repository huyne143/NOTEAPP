package com.example.finalnote_app;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;  // Import Toast
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private DatabaseHelper dbHelper;
    private SQLiteDatabase database;

    FloatingActionButton addNoteBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addNoteBtn = findViewById(R.id.add_note_btn);

        addNoteBtn.setOnClickListener((v)-> startActivity(new Intent(MainActivity.this, NoteDetailsActivity.class)));

        dbHelper = new DatabaseHelper(this);
        database = dbHelper.getWritableDatabase();

        // Example: Save a note
        saveNote("Meeting", "Prepare agenda for the team meeting");

        // Example: Retrieve all notes
        List<Note> allNotes = getAllNotes();
        for (Note note : allNotes) {
            Log.d("Note", "ID: " + note.getId() + ", Title: " + note.getTitle() + ", Content: " + note.getContent());
        }
    }

    private void saveNote(String title, String content) {
        ContentValues values = new ContentValues();
        values.put("title", title);
        values.put("content", content);

        long rowId = database.insert("NoteTable", null, values);

        if (rowId != -1) {
            Toast.makeText(this, "Note saved successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Failed to save note!", Toast.LENGTH_SHORT).show();
        }
    }

    private List<Note> getAllNotes() {
        List<Note> notes = new ArrayList<>();
        String[] projection = {"_id", "title", "content"};
        Cursor cursor = database.query("NoteTable", projection, null, null, null, null, null);

        while (cursor.moveToNext()) {
            @SuppressLint("Range") long id = cursor.getLong(cursor.getColumnIndex("_id"));
            @SuppressLint("Range") String title = cursor.getString(cursor.getColumnIndex("title"));
            @SuppressLint("Range") String content = cursor.getString(cursor.getColumnIndex("content"));

            Note note = new Note();
            note.setId(id);
            note.setTitle(title);
            note.setContent(content);

            notes.add(note);
        }

        cursor.close();
        return notes;
    }

}// ... Other methods

